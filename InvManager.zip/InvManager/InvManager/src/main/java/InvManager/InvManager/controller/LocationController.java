package InvManager.InvManager.controller;

import InvManager.InvManager.models.Location;
import InvManager.InvManager.services.LocationService;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@ComponentScan(basePackages = "InvManager.InvManager.services.LocationService")
@RestController
@RequestMapping("/api/v1/")

public class LocationController{
    //@Autowired
    private LocationService locationService;

    public LocationController(LocationService locationService) {

        this.locationService = locationService;
    }

    // Add a new location
    @PostMapping("/Post")
    @RequestMapping(value = "/path/post", method = RequestMethod.POST)
    public ResponseEntity<Location> addLocation(@RequestBody Location location) {

        return new ResponseEntity<>(locationService.addLocation(location), HttpStatus.CREATED);

    }

    // Delete a location by its ID
    @DeleteMapping({"/{locationId}"})
    public ResponseEntity<Location> deleteLocation(@PathVariable("locationId") int locationId) {
        locationService.deleteLocation(locationId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

