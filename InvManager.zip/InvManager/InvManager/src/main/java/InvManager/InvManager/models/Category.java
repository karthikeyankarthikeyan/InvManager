package InvManager.InvManager.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;


@Entity
@Data
@Table(name = "Categories")
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class Category {
    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "category_id")
    private int categoryId;
    @Column(name = "category_name")
    public String categoryName;
    @Column(name = "subcategory_name")
    private String subcategoryName;
    @Column(name = "subcategory_type")
    private String SubcategoryType;
    @CreationTimestamp
    @Column(name = "modified_at")
    private Timestamp modifiedAt;
    @Column(name = "modified_by")
    private String modifiedBy;

    //@OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
    //private List<Inventory> inventoryList;


    public void setId(int categoryId) {
        this.categoryId = categoryId;

    }

}



