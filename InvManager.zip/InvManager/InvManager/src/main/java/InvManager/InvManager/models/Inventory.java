package InvManager.InvManager.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "Inventories")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Inventory {
    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "inventory_id")
    private Integer inventoryId;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;

    @ManyToOne
    @JoinColumn(name = "location_id")
    private Location location;

    @Column(name = "inventory_name")
    private String inventoryName;
    @Column(name = "asset_no")
    private Integer assetNo;
    @Column(name = "purchase_price")
    private String purchasePrice;
    @Column(name = "warranty_expired_date")
    private String warrantyExpiredDate;
    @Column(name = "status")
    private String status;
    @Column(name = "comment")
    private String comment;
    @CreationTimestamp
    @Column(name = "modified_at")
    private Timestamp modifyAt;
    @Column(name = "modified_by")
    private String modifiedBy;


    public void setId(int inventoryId) {
    }
}


