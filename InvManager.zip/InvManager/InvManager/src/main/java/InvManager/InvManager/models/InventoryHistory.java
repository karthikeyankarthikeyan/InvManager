package InvManager.InvManager.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "InventoriesHistory")
@AllArgsConstructor
@NoArgsConstructor
@Builder

@IdClass(inventoryHistoryId.class)

public class InventoryHistory {
        @Id
        //@GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "inventoryhistory_id")
        private Integer inventoryHistoryId;
        @Id
        //@GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "inventory_id")
        private Integer inventoryId;
        @Column(name = "inventory_name")
        private String inventoryName;
        @Column(name = "asset_no")
        private Integer assetNo;
        @Column(name = "purchase_price")
        private String purchasePrice;
        @Column(name = "warranty_expired_date")
        private String warrantyExpiredDate;
        @Column(name = "status")
        private String status;
        @Column(name = "comment")
        private String comment;
        @CreationTimestamp
        @Column(name = "modified_at")
        private Timestamp modifyAt;
        @Column(name = "modified_by")
        private String modifiedBy;

        private String operation; // Store "ADD", "UPDATE", or "DELETE"
        private Timestamp LocalDateTime ;

        @ManyToOne
        @JoinColumn(name = "inventory_id", insertable= false, updatable = false)
        private Inventory inventory;

        public void setInventory(Inventory inventory) {
        }

        public void setTimestamp(java.time.LocalDateTime now) {

        }
}
