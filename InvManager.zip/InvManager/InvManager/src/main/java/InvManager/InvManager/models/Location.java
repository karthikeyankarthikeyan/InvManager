package InvManager.InvManager.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


@Entity
@Data
@Table(name = "locations")
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class Location {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "location_id")
    private Integer locationId;
    @Column(name = "floor_number")
    private Integer floorNumber;
    @Column(name = "block")
    private String block;
    @Column(name = "area")
    private String area;
    @CreationTimestamp
    @Column(name = "modified_at")
    private Timestamp modifiedAt;
    @Column(name = "modified_by")
    private String modifiedBy;

    @OneToMany(mappedBy = "location", cascade = CascadeType.ALL)
    private List<Inventory> inventories;
}
