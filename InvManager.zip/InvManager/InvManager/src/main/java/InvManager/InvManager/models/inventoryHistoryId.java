package InvManager.InvManager.models;

import java.io.Serializable;

public class inventoryHistoryId implements Serializable {

     private int inventoryId;
     private int inventoryHistoryId;

}
