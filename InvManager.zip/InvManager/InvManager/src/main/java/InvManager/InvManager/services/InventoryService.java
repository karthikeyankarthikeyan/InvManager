package InvManager.InvManager.services;

import InvManager.InvManager.models.Inventory;

import java.util.List;
import java.util.Optional;

public interface InventoryService {

    public Inventory addInventory(Inventory inventory);

    public void deleteInventory(int inventoryId);

    public Inventory updateInventory(int inventoryId, Inventory updatedInventory);

    public List<Inventory> listAllInventories();

    public Optional<Inventory> searchInventory(int assetNo);


}

