package InvManager.InvManager.services;

import InvManager.InvManager.models.Inventory;
import InvManager.InvManager.repositories.InventoryRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public  abstract class InventoryServiceImpl implements InventoryService {

    private InventoryRepository inventoryRepository;

    public InventoryServiceImpl(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }

    @Override
    public Inventory addInventory(Inventory inventory) {
        return inventoryRepository.save(inventory);
    }

    @Override
    public void deleteInventory(int inventoryId) {
        inventoryRepository.deleteById(inventoryId);
    }

    @Override

    public Inventory updateInventory(int inventoryId, Inventory updatedInventory) {
        if (inventoryRepository.existsById(inventoryId)) {
            updatedInventory.setId(inventoryId);

            return inventoryRepository.save(updatedInventory);
        } else {
            throw new RuntimeException("Inventory not found");
        }
    }

    @Override

    public List<Inventory> listAllInventories() {
        return inventoryRepository.findAll();
    }

    @Override
    public Optional<Inventory> searchInventory(int assetNo)
    {

        return inventoryRepository.findByassetNo(assetNo);
    }

}


