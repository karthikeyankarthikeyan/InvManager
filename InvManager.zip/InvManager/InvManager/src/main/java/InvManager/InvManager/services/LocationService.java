package InvManager.InvManager.services;

import InvManager.InvManager.models.Location;

public interface LocationService {

    public  Location addLocation(Location location);

    public void deleteLocation(int locationId);
}
