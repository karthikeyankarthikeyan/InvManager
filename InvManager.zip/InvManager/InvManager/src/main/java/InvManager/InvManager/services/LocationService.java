package InvManager.InvManager.services;

import InvManager.InvManager.models.Inventory;
import InvManager.InvManager.models.Location;

import java.util.List;

public interface LocationService {

    public  Location addLocation(Location location);

    public void deleteLocation(int locationId);

    List<Inventory> findInventoriesByLocationArea(String area);
}
