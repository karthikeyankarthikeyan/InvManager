package InvManager.InvManager.services;

import InvManager.InvManager.models.Location;
import InvManager.InvManager.repositories.LocationRepository;
import org.springframework.stereotype.Service;

@Service
public class LocationServiceImpl implements LocationService {
    private final LocationRepository locationRepository;

    public LocationServiceImpl(LocationRepository locationRepository) {

        this.locationRepository = locationRepository;
    }

    @Override
    //Adding a  new category

    public Location addLocation(Location location) {

        return locationRepository.save(location);
    }

    @Override
    //Delete a category by its ID

    public void deleteLocation(int locationId) {

        locationRepository.deleteById(locationId);
    }

}
