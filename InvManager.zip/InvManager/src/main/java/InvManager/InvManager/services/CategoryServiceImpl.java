package InvManager.InvManager.services;

import InvManager.InvManager.models.Category;
import InvManager.InvManager.models.Inventory;
import InvManager.InvManager.repositories.CategoryRepository;
import InvManager.InvManager.repositories.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

      @Service
        public class CategoryServiceImpl implements CategoryService {
          @Autowired
        private final CategoryRepository categoryRepository;

        public CategoryServiceImpl(CategoryRepository categoryRepository) {

            this.categoryRepository = categoryRepository;
        }

        @Autowired
        private InventoryRepository inventoryRepository;


        @Override
        //Adding a  new category

        public Category addCategory(Category category) {
            return categoryRepository.save(category);
        }

        @Override
        //Delete a category by its ID

        public void deleteCategory(int categoryId) {
             categoryRepository.deleteById(categoryId);
        }

        @Override
        // List all categories

        public List<Category> listAllCategories() {
            return categoryRepository.findAll();
        }

        @Override
        //update an existing category

        public Category updateCategory(int categoryId, Category updatedCategory) {
            if (categoryRepository.existsById(categoryId)) {
                updatedCategory.setId(categoryId);

                return categoryRepository.save(updatedCategory);
            } else {
                throw new RuntimeException("Category not found");
            }
        }

        @Override
        public Optional<Category> searchCategory(String categoryName) {

            return  categoryRepository.findBycategoryName(categoryName);
        }

        @Override
          public List<Inventory> findInventoriesByCategoryName(String categoryName) {
              List<Category> categories = categoryRepository.findByCategoryName(categoryName);

              if (!categories.isEmpty()) {
                  Category category = categories.get(0);
                  return inventoryRepository.findByCategory(category);
              }

              return Collections.emptyList();
          }

    }













