package InvManager.InvManager.services;

import InvManager.InvManager.models.Inventory;
import org.springframework.context.annotation.ComponentScan;

import java.util.List;
import java.util.Optional;
@ComponentScan(basePackages = {"InvManager.InvManager.services"})

public interface InventoryService {

    public Inventory addInventory(Inventory inventory);

    public void deleteInventory(int inventoryId);

    public Inventory updateInventory(int inventoryId, Inventory updatedInventory);

    public List<Inventory> listAllInventories();

    public Optional<Inventory> searchInventory(int assetNo);


}

