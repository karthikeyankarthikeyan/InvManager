package InvManager.InvManager.services;

import InvManager.InvManager.models.Inventory;
import InvManager.InvManager.models.InventoryHistory;
import InvManager.InvManager.repositories.InventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;


@Service
public  abstract class InventoryServiceImpl implements InventoryService {
    @Autowired
    private InventoryRepository inventoryRepository;

    public InventoryServiceImpl(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }

    @Override
    public Inventory addInventory(Inventory inventory) {
        Inventory savedInventory = inventoryRepository.save(inventory);
        addHistory(savedInventory, "ADD");
        return savedInventory;
    }

    @Override
    public void deleteInventory(int inventoryId) {
        Optional<Inventory> inventoryOptional = inventoryRepository.findById(inventoryId);
        inventoryOptional.ifPresent(inventory -> {
        inventoryRepository.deleteById(inventoryId);
        addHistory(inventory, "DELETE"); });
    }

    @Override
    public Inventory updateInventory(int inventoryId, Inventory updatedInventory) {
        if (inventoryRepository.existsById(inventoryId)) {
            updatedInventory.setId(inventoryId);
            Inventory savedInventory = inventoryRepository.save(updatedInventory);
            addHistory(savedInventory, "UPDATE");
            return savedInventory;

        } else {
            throw new RuntimeException("Inventory not found");
        }
    }

    @Override
    public List<Inventory> listAllInventories() {
        return inventoryRepository.findAll();
    }

    @Override
    public Optional<Inventory> searchInventory(int assetNo)
    {

        return inventoryRepository.findByassetNo(assetNo);
    }
    private void addHistory(Inventory inventory, String operation)
    {
        InventoryHistory historyEntry = new InventoryHistory();
        historyEntry.setInventory(inventory);
        historyEntry.setOperation(operation);
        historyEntry.setTimestamp(LocalDateTime.now());
        inventory.getHistory().add(historyEntry);
    }

}


