package InvManager.InvManager.controller;

import InvManager.InvManager.models.Inventory;
import InvManager.InvManager.services.InventoryService;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

//@ComponentScan(basePackages = "InvManager.InvManager.services.InventoryService")
@RestController
@RequestMapping("/v3/api-docs")
public class InventoryController {

    private final InventoryService inventoryService;


    public InventoryController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    @PostMapping("/add")
    public ResponseEntity<Inventory> addInventory(@RequestBody Inventory inventory) {
        Inventory addedInventory = inventoryService.addInventory(inventory);
        return new ResponseEntity<>(addedInventory, HttpStatus.CREATED);
    }

    @DeleteMapping("/{inventoryId}")
    public ResponseEntity<Void> deleteInventory(@PathVariable int inventoryId) {
        inventoryService.deleteInventory(inventoryId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/{inventoryId}")
    public <inventoryId> ResponseEntity<Inventory> updateInventory(@PathVariable int inventoryId, @RequestBody Inventory updatedInventory) {
        try {
            Inventory inventory = inventoryService.updateInventory(inventoryId, updatedInventory);
            return new ResponseEntity<>(inventory, HttpStatus.OK);
        } catch (RuntimeException e) {  // Catch the exception you're throwing in the service layer

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        }

    }

    @GetMapping("/getAll/list")
    public ResponseEntity<List<Inventory>> listAllInventories(){
        List<Inventory> inventories = inventoryService.listAllInventories();
        return new ResponseEntity<>(inventories, HttpStatus.OK);
    }

    @GetMapping("/search/assetNo")
    //search a inventory
    public ResponseEntity<Inventory> searchInventory(@RequestParam int assetNo) {

        Optional<Inventory> inventory = inventoryService.searchInventory(assetNo);

        return inventory.map(ResponseEntity::ok)

                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }



}


