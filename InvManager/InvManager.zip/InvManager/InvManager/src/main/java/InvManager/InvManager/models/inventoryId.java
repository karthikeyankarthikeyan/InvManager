package InvManager.InvManager.models;

import java.io.Serializable;

public class inventoryId implements Serializable {

    private int inventoryId; // Constructors, getters, setters, equals, and hashCode methods }
}

