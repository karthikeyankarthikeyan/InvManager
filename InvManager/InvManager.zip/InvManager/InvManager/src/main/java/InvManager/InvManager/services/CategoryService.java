package InvManager.InvManager.services;

import InvManager.InvManager.models.Category;
import InvManager.InvManager.models.Inventory;

import java.util.List;
import java.util.Optional;

public interface CategoryService {

 public Category addCategory(Category category);

 public void deleteCategory(int categoryId);

 public List<Category> listAllCategories();

 public Category updateCategory(int categoryId, Category updatedCategory);

 public Optional<Category> searchCategory(String categoryName);

 List<Inventory> findInventoriesByCategoryName(String categoryName);
}
