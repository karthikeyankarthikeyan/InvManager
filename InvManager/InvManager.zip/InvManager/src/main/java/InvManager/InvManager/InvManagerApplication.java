package InvManager.InvManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//@ComponentScan(basePackages = "InvManager.InvManager.services")
public class InvManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(InvManagerApplication.class, args);
	}

}
