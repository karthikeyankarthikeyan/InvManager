package InvManager.InvManager.controller;

import InvManager.InvManager.models.Category;
import InvManager.InvManager.models.Inventory;
import InvManager.InvManager.services.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


//@ComponentScan(basePackages = "InvManager.InvManager.services.CategoryService")
@RestController
@RequestMapping("/v1/api/CategoryController")
public class CategoryController {
////    public CategoryController(){}
//
////    @Autowired
    private CategoryService categoryService;
//
    public CategoryController(CategoryService categoryService) {
            this.categoryService = categoryService;
        }

        //List all categories
        @GetMapping("/ListAllCategories")
        public ResponseEntity<List<Category>> listAllCategories() {

            return new ResponseEntity<>(categoryService.listAllCategories(), HttpStatus.OK);

        }

        // Add a new category
        @PostMapping("AddCategory/category")
        public ResponseEntity<Category> addCategory(@RequestBody Category category) {
            return new ResponseEntity<>(categoryService.addCategory(category), HttpStatus.CREATED);

        }
        // Delete a category by its ID
        @DeleteMapping("DeleteCategory/{categoryId}")
        public ResponseEntity<Category> deleteCategory(@PathVariable int categoryId) {
            categoryService.deleteCategory(categoryId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        //Update an existing category
        //@Param
        //@Param
        //@Return
        @PutMapping ("UpdateCategory/{categoryId}")

        public <categoryId> ResponseEntity<Category> updateCategory(@PathVariable  int categoryId, @RequestBody Category updatedCategory) {

            try {
                Category category = categoryService.updateCategory(categoryId, updatedCategory);

                return new ResponseEntity<>(category, HttpStatus.OK);

            } catch (RuntimeException e) {  // Catch the exception you're throwing in the service layer

                return new ResponseEntity<>(HttpStatus.NOT_FOUND);

            }

        }
//
    @GetMapping("/SearchCategory")
    //search a inventory
    public ResponseEntity<Category> searchCategory(@RequestParam String categoryName) {

        Optional<Category> category = categoryService.searchCategory(categoryName);

        return category.map(ResponseEntity::ok)

                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }
//
////    @GetMapping("/SearchInventoriesByCategoryName")
////    public ResponseEntity<List<Inventory>> searchInventoriesByCategoryName(@RequestParam("categoryName") String categoryName) {
////        List<Inventory> inventories = categoryService.findInventoriesByCategoryName(categoryName);
////
////        if (inventories.isEmpty()) {
////            return ResponseEntity.notFound().build();
////        }
////
////        return ResponseEntity.ok(inventories);
////    }


}


