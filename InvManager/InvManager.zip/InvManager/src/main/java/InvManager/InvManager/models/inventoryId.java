//package InvManager.InvManager.models;
//
//import java.io.Serializable;
//
//public class inventoryId implements Serializable {
//
//    private int inventoryId;
//}
//
