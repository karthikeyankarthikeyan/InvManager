package InvManager.InvManager.repositories;

import InvManager.InvManager.models.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Integer> {


    Optional<Category> findBycategoryName(String categoryName);

    void deleteById(int categoryId);

    // void deleteBycategoryId(int categoryId);

    //List<Category> findByCategoryName(String categoryName);

}



