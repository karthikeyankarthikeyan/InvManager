//package InvManager.InvManager.repositories;
//
//import InvManager.InvManager.models.InventoryHistory;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface InventoryHistoryRepository extends JpaRepository<InventoryHistory, Integer> {
//
//}