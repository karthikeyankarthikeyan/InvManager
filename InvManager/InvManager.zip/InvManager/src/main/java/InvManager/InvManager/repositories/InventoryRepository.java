package InvManager.InvManager.repositories;

import InvManager.InvManager.models.Category;
import InvManager.InvManager.models.Inventory;
import InvManager.InvManager.models.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InventoryRepository extends JpaRepository<Inventory, Integer> {

    Optional<Inventory> findByassetNo(int assetNo);

    void deleteByinventoryId(int inventoryId);

    void deleteById(int inventoryId);

    // List<Inventory> findByCategory(Category category);

    //List<Inventory> findByLocation(Location location);


}

