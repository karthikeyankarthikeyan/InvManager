package InvManager.InvManager.services;

import InvManager.InvManager.models.Inventory;
import InvManager.InvManager.models.Location;
import org.springframework.stereotype.Service;

import java.util.List;

//@Service
public interface LocationService {

    public  Location addLocation(Location location);

    public void deleteLocation(int locationId);

    //List<Inventory> findInventoriesByLocationArea(String area);
}
