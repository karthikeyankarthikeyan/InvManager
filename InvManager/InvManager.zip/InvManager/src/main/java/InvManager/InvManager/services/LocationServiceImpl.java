package InvManager.InvManager.services;

import InvManager.InvManager.models.Inventory;
import InvManager.InvManager.models.Location;
import InvManager.InvManager.repositories.InventoryRepository;
import InvManager.InvManager.repositories.LocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
@Service

public class LocationServiceImpl implements LocationService {
    private LocationRepository locationRepository;

    public LocationServiceImpl(LocationRepository locationRepository) {

        this.locationRepository = locationRepository;
    }
//    @Autowired
//    private InventoryRepository inventoryRepository;

    @Override

    public Location addLocation(Location location) {

        return locationRepository.save(location);
    }

    @Override
    //Delete a category by its ID

    public void deleteLocation(int locationId) {

        locationRepository.deleteById( locationId);
    }
//    @Override
//    public List<Inventory> findInventoriesByLocationArea(String area) {
//        List<Location> locations = locationRepository.findByArea(area);
//
//        if (!locations.isEmpty()) {
//            Location location = locations.get(0);
//            return inventoryRepository.findByLocation(location);
//        }
//
//        return Collections.emptyList();
//    }

}
