import React, { useState } from 'react';

function App() {
  const [assetNo, setAssetNo] = useState('');
  const [inventoryName, setInventoryName] = useState('');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [dateOfPurchase, setDateOfPurchase] = useState('');
  const [warrantyExpiredDate, setWarrantyExpiredDate] = useState('');
  const [status, setStatus] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // You can handle form submission logic here
    // For this example, we'll just show an alert
    setIsSubmitted(true);
    alert('Successfully Submitted An Item.');
    setTimeout(() => {
      setIsSubmitted(false);
    }, 500);
  };

  return (
    <div className="App">
      <h1>Add Item Here</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="assetNo">Asset No:</label>
          <input
            type="text"
            id="assetNo"
            value={assetNo}
            onChange={(e) => setAssetNo(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="inventoryName">Inventory Name:</label>
          <input
            type="text"
            id="inventoryName"
            value={inventoryName}
            onChange={(e) => setInventoryName(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="purchasePrice">Purchase Price:</label>
          <input
            type="number"
            id="purchasePrice"
            value={purchasePrice}
            onChange={(e) => setPurchasePrice(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="dateOfPurchase">Date of Purchase:</label>
          <input
            type="date"
            id="dateOfPurchase"
            value={dateOfPurchase}
            onChange={(e) => setDateOfPurchase(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="warrantyExpiredDate">Warranty Expired Date:</label>
          <input
            type="date"
            id="warrantyExpiredDate"
            value={warrantyExpiredDate}
            onChange={(e) => setWarrantyExpiredDate(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="status">Status:</label>
          <input
            type="text"
            id="status"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          />
        </div>
        <div>
          <button type="submit" style={{ display: 'block', margin: '0 auto' }}>
            Submit
          </button>
        </div>
      </form>
      {isSubmitted && (
        <div className="success-alert">
          Successfully Submitted An Item.
        </div>
        
      )}
    </div>
  );
}

export default App;

