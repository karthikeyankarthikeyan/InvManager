import React from 'react';
import './AddItem.css';
import AddItem from './AddItem';

function App() {
  return (
    <div className="App">
      <AddItem/>
    </div>
  );
}

export default App;
