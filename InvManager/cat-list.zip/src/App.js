import React from 'react';
import './InventoryCategoryList.css'; // Import your CSS file here
import InventoryCategoryList from './InventoryCategoryList'; // Make sure the path is correct

function App() {
  return (
    <div className="App">
      <InventoryCategoryList />
    </div>
  );
}

export default App;

