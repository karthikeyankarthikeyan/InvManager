import React, { useState } from 'react';

function InventoryList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [inventoryItems, setInventoryItems] = useState([
    {
      assetNo: 'INV001',
      name: 'Item 1',
      purchasePrice: '$100',
      dateOfPurchase: '2023-01-15',
      warrantyExpiredDate: '2025-01-15',
      status:'Active'
    },
    {
      assetNo: 'INV002',
      name: 'Item 2',
      purchasePrice: '$150',
      dateOfPurchase: '2023-02-20',
      warrantyExpiredDate: '2026-02-20',
      status:'Inactive',
    },
    // Add more inventory items here
  ]);

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleDeleteClick = (index) => {
    const shouldDelete = window.confirm('Are you sure you want to delete this item?');

    if (shouldDelete) {
      const updatedInventory = [...inventoryItems];
      updatedInventory.splice(index, 1);
      setInventoryItems(updatedInventory);
      window.alert('Successfully deleted the item.');
    }
  };

  return (
    <div className="InventoryList">
      <h1>Inventory List</h1>
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search..."
          value={searchTerm}
          onChange={handleSearchChange}
        />
      </div>
      <table>
        <thead>
          <tr>
            <th>Asset No</th>
            <th>Inventory Name</th>
            <th>Purchase Price</th>
            <th>Date of Purchase</th>
            <th>Warranty Expired Date</th>
            <th>Status</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {inventoryItems.map((item, index) => (
            <tr key={index}>
              <td>{item.assetNo}</td>
              <td>{item.name}</td>
              <td>{item.purchasePrice}</td>
              <td>{item.dateOfPurchase}</td>
              <td>{item.warrantyExpiredDate}</td>
              <td>{item.status}</td>
              <td>
                <button className="edit-button">Edit</button>
              </td>
              <td>
                <button className="delete-button" onClick={() => handleDeleteClick(index)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="add-button">ADD ITEM</button>
    </div>
  );
}

export default InventoryList;
