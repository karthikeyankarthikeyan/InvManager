package com.example.todo.model;

public enum TodoStatus {
    COMPLETED, NOT_COMPLETED
}